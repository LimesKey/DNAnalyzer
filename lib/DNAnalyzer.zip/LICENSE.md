# Terms of this license

All rights reserved. This license is a legal agreement between you and the author of the software (the "Author"). By obtaining, using, and/or copying this software, you agree that you have read, understood, and agree to be bound by the terms of this license. If you do not agree to these terms, do not obtain or use this software. The user of this software is considered to be the "Licensee" and the Author is the "Licensor".

## 1. Grant of license

      The Licensor reserves the right to change the terms of this License at any time. The Licensor holds the right to terminate this License at any time.

## 2. Grant of rights

    The Licensee may only use the Software for non-commercial purposes. The Licensee may not use the Software for any commercial purpose and may not, under any circumstances, distribute, copy, transfer the Software to any party other than the Licensor. **This includes copying, modifying, and/or distributing any part of the Software for any use.** The Licensee may not use the Software in any manner for which the Software may be a component of a derivative work.

## 3. Prohibited uses

    The Licensee may not use the Software for any purposes that are not expressly permitted by this License. The Licensee may not, under any circumstances, use the Software in a manner that is intended to interfere with or damage the Software or the rights of the Licensor.