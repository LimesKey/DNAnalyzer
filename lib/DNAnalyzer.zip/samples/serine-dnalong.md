1. Open `Main.java`
   - `Main.java` is the entry point of the program.
   - <img src="img/Screenshot 2022-08-24 123940.png" width="200"/>
2. Run the program
   - <img src="img/Screenshot 2022-08-24 124700.png" width="400"/>